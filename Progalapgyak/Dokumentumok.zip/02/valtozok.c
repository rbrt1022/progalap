#include <stdio.h>

int main() {
  int szam;

  szam = 5;
  szam = szam * 10;

  float pi = 3.1415;
  double d = 2.76468435186;

  printf("A szam = %d\n", szam);
  printf("pi:%f\nd:%lf\n", pi, d);

  char kar;
  kar = 'X';

  printf("kar = %c\n", kar);

  return 0;
}
