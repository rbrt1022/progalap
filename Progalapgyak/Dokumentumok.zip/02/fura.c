#include <limits.h>
#include <stdio.h>

int main() {
  int x = INT_MAX;

  printf("x=%d\nx+1=%d\n", x, x + 1);

  return 0;
}
