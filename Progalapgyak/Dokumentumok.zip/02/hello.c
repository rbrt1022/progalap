#include <stdio.h>

int main() {
  printf("Hello, progalap!\n");
  
  return 0;
}
