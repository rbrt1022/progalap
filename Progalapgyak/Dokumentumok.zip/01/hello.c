#include <stdio.h>

int main() {
  printf("Hello, Progalap\n");

  return 0;
}
